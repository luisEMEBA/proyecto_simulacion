﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class viento : MonoBehaviour
{
    //Empieza variables sonido del viento
    //finaliza variables sonido del viento
    float condicional = 500; //Éste valor hace parte de la función que determina cuándo se genera o no viento
    //a futuro la idea es organizar un marco más complejo que permita la generación o no generación de viento
    //dependiendo de variables introducidas por el usuario, por ejemplo intensidad del clima.
    int control_de_particulas = 0;//Variable de control para alternar entre la generación, el movimiento y
    //la eliminación de las partículas de viento.
    int i;//Número que dicta el número de partículas de viento, una vez más puede venir determinado por 
    //variables introducidas por el usuario como intensidad del clima.
    float seno = 1;//Su única función es alternar el valor Y de la posición de las partículas de aire
    //con el fin de emular el movimiento sinusoidal de una corriente de aire.
    float control_seno;//Permite variar la amplitud de los senos descritos por el movimiento de la corriente de aire.
    public List<GameObject> objetos = new List<GameObject>();//Lista que contiene a las partículas generadas.
    Vector3 posicion = new Vector3(0,0,0);//Utilizado para mover las partículas creadas anteriormente.
    float movimiento = 1;//Cantidad de desplazamiento de las partículas de aire, puede parametrizarse bajo variables (aceleración)
    //introducidas por el usuario, ejemplo: Velocidad del viento.
    GameObject g;//Objeto mediante el cuál se instancian las partículas de aire.
    public GameObject bola;//forma física de las partículas de aire
    public GameObject dron;//posición del dron: se utiliza para eliminar las partículas de aire una vez que estas se encuentran 
    //a determinada lejanía del mismo.
    Vector3 posicion_dron;//posición para llevar a cabo lo anterior.
    Vector3 posicion_ultima_particula;//Al restarle a esta posición la del dron obtenemos el parámetro de lejanía específicado anteriormente.
    Vector3 distancia_de_influencia = new Vector3(1,1,1);//resultande de la resta entre posición última partícula y posición dron.
    Vector3 direccion;//Pensada para dotar de dirección y sentido al viento, con lo que sería posible generar corrientes
    Vector3 posicion_primera_particula;//
    Vector3 distancia_de_influencia_primera = new Vector3(1,1,1);//
    //de viento que viajen en varias direcciones, creando un entorno más real.
    //EMPIEZA definición de variables con las que se trabajará el cálculo de fuerza y torque.     
    Vector3 posicion_para_comparar;
    float distanciamiento = 1;
    public static Vector3 direccion_viento;
    public static float fuerza_viento;
    float area = 1;
    float presion = 2; //pilas porque debe venir determinada por lo de intensidad del clima.
    float coeficiente = 0.5f;
    public static Vector3 torque;
    float radio;
    float rang = 2;
    float frecuencia;
    float cond;
    int mul;
    //FINALIZA definición de variables con las que se trabajará el cálculo de fuerza y torque.
    //Empieza definición de variables que determinarán las condiciones climáticas

    //finaliza definición de variables que determinarán las condiciones climáticas
   void Start(){
       i = 120;//numero de partículas de aire a generar
       acceder_datos(dato_slides.rango);
    }
   void Update(){
    acceder_datos(valor_condi_amb.rango);
    //empieza definición de variables para describir un seno con el movimiento
    control_seno = (Random.Range(0.0f,1.0f));
    seno = seno + 0.1f; 
    if(seno >= 100){
    seno = 0;
    }
    //finaliza definición de variables para describir un seno.
    posicion_dron = dron.gameObject.GetComponent<Transform>().position;
    //Empieza generación de partículas (en caso de cumplir la condición) -- Hay que establecer un marco más complejo para
    //que se cumpla con la misma.    
    condicional = Random.Range(frecuencia, (-1 * frecuencia));
    if(condicional >= -1*cond && condicional <= cond && control_de_particulas == 0){
    for (int n = 0; n <= i; n++)
        {
            Vector3 position = new Vector3(Random.Range(0, distanciamiento), Random.Range(-2.0f, 2.0f),Random.Range(0, distanciamiento)); //posición con parámetros aleatorios 
            g = Instantiate(bola, position, Quaternion.identity);//se instancia una partícula de aire.
            objetos.Add(g);//se añade la instancia generada anteriormente a la lista de instancias
            direccion = new Vector3(Random.Range(-1f , 1f),Random.Range(0.1f, 1f),Random.Range(-1f , 1f));//Se aspiró a dotar una dirección única
            //a cada grupo de partículas generadas
        }    
        control_de_particulas = 1;//es posible avanzar a fase de movimiento
    }
    //finaliza creación de partículas de aire
    //empieza movimiento aplicado a partículas de aire generadas
    if(control_de_particulas == 1){
        posicion.x = 0;
        posicion.y = 0;
        posicion.z = 0; 
        posicion.x = posicion.x + movimiento;
        posicion.z = posicion.z + movimiento;
        posicion.y = (posicion.y + movimiento)*(Mathf.Sin(seno)*control_seno);//para dibujar un seno en el plano xy
        posicion.x = posicion.x * direccion.x;posicion.y = posicion.y * direccion.y;posicion.z = posicion.z * direccion.z;
        for(int n = 0; n <= i; n++){
        objetos[n].transform.position += posicion;//se actualiza posición
        }
    posicion_primera_particula = objetos[0].gameObject.GetComponent<Transform>().position;
    distancia_de_influencia_primera = posicion_primera_particula - posicion_dron;    
    posicion_ultima_particula = objetos[(i-1)].gameObject.GetComponent<Transform>().position;
    distancia_de_influencia = posicion_ultima_particula - posicion_dron;//se empieza a calcular la lejanía de las partículas
    //con respecto al dron, se toma la posición de la penúltima partícula generada.
    }
    //finaliza movimiento aplicado a partículas
    //empieza comprobación de colisión y cálculo de fuerza
    if(distancia_de_influencia_primera.x <= 10 && distancia_de_influencia_primera.y <= 10 && distancia_de_influencia_primera.z <= 10 || 
    distancia_de_influencia.x <= 10 && distancia_de_influencia.y <= 10 && distancia_de_influencia.z <= 10){ //Esta comparación es para saber si el dron
                     //se encuentra más o menos cerca al viento.
     foreach(GameObject g in objetos){
      posicion_para_comparar = g.gameObject.GetComponent<Transform>().position;
      float restax = Mathf.Abs(posicion_para_comparar.x - posicion_dron.x);
      float restay = Mathf.Abs(posicion_para_comparar.y - posicion_dron.y);
      float restaz = Mathf.Abs(posicion_para_comparar.z - posicion_dron.z);
      if(restay <= 4 && restax <= 4 && restaz <= 4){
      Vector3 r = posicion_para_comparar - posicion_dron;
      fuerza_viento = area * presion * coeficiente;
      direccion_viento = direccion;
      torque = new Vector3(restax*fuerza_viento*direccion.x, restay*fuerza_viento*direccion.y, restaz*fuerza_viento*direccion.z);
      Debug.Log("¡Lo golpeó! y el torque es igual a :" + torque);
      }
     }                                                                                              
    }
    //finaliza comprobación de colisión y cálculo de fuerza.
    //empieza eliminación de partículas de aire una vez se encuentran suficientemente lejos del dron
    if(distancia_de_influencia.magnitude >= 150){
    foreach (GameObject g in objetos){
     GameObject.Destroy(g);
    }
    objetos.Clear();
       control_de_particulas = 0;//se regresa a fase de generación
    }
    //finaliza eliminación de partículas de aire lejanas.
    }
    void acceder_datos(float ranga){
    //Empieza parametrización de valores climáticos  
    presion = (ranga*5) + 0.2f;
    mul = Mathf.RoundToInt(120*ranga);
    distanciamiento = (7 * (1 - ranga)) + 1f;
    if(ranga <= 0.25f){
    frecuencia = 36000 * ranga;
    cond = 30;
    }
    if(ranga >= 0.25f && ranga <= 0.5f){
    frecuencia = 4000 * ranga;
    cond = 40;
    }
    if(ranga >= 0.5f && ranga <= 0.75f){
    frecuencia = 466 * ranga;
    cond = 30;
    }
    if(ranga >= 0.75f && ranga <= 1f){
    frecuencia = 15 * ranga;
    cond = 10;
    }
    movimiento = (4.9f * ranga) + 0.1f;
    //Finaliza parametrización de valores climáticos.
    fuerza_viento = 0; //Cada cuadro se inicia en cero para evitar que afecte al dron sin que este esté cerca.
    }
    
}
