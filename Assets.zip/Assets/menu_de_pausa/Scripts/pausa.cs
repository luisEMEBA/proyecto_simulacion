﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class pausa : MonoBehaviour
{
    public static bool pausado = false;
    public GameObject menUI;
    void start(){
    menUI.SetActive(false);    
    }
    void Update()
    {
     if(Input.GetKeyDown(KeyCode.Return)){
     if(pausado){
     resumir();
     }
     else{
     pausar();
     }
     }   
    }
    void pausar(){
    Cursor.visible = true;
    menUI.SetActive(true);
    Time.timeScale = 0f;
    pausado = true;
    Cursor.lockState = CursorLockMode.None;
    }
    void resumir(){
    Cursor.visible = false;
    menUI.SetActive(false);
    Time.timeScale = 1f;
    pausado = false;
    Cursor.lockState = CursorLockMode.Locked;
    }
}
