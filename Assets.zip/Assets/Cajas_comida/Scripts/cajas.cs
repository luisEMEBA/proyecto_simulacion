﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cajas : MonoBehaviour
{
    public static GameObject caja;
    public GameObject caja_original;
    public static List<GameObject> objetos = new List<GameObject>();
    int i;
    // Start is called before the first frame update
    void Start()
    {
    i = 5;
    for (int n = 0; n <= i; n++)
        {
            Vector3 position = new Vector3(Random.Range(-20, 20), 1, Random.Range(-20, 20)); //posición con parámetros aleatorios 
            caja = Instantiate(caja_original, position, Quaternion.identity);//se instancia una partícula de aire.
            objetos.Add(caja);//se añade la instancia generada anteriormente a la lista de instancias
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
