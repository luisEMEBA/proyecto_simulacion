﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cajas : MonoBehaviour
{
    public static GameObject caja;
    public GameObject caja_original;
    public static List<GameObject> objetos = new List<GameObject>();
    int i;
    float[] tg, vy,x,y,z;
    Quaternion p;
    
    // Start is called before the first frame update
    void Start()
    {
        i = 5;
        tg = new float[i];
        vy = new float[i];

        x = new float[i];
        y = new float[i];
        z = new float[i];

    

        for (int n = 0; n < i; n++)
        {
            
            Vector3 position = new Vector3(UnityEngine.Random.Range(-20, 20), 1, UnityEngine.Random.Range(-20, 20)); //posición con parámetros aleatorios 
            caja = Instantiate(caja_original, position, Quaternion.identity);//se instancia una partícula de aire.
            objetos.Add(caja);//se añade la instancia generada anteriormente a la lista de instancias
            vy[n] = 0;
            tg[n] = 0;

        }
        objetos[0].transform.position = new Vector3(5, 0.5f, 0);
        objetos[0].transform.rotation = Quaternion.Euler(45, 0, 0);


        x[0] = 1;
        y[0] = 1;
        z[0] = 0;
    }



    void gravedad(int n)
    {
        vy[n] = vy[n] - 9.8f * tg[n];
        y[n] += vy[n] * Time.deltaTime;

    }
    // Update is called once per frame
    void FixedUpdate()
    {
        for (int n = 0; n < i; n++)
        {
            x[n] = objetos[n].gameObject.GetComponent<Transform>().position.x;
            y[n] = objetos[n].gameObject.GetComponent<Transform>().position.y;
            z[n] = objetos[n].gameObject.GetComponent<Transform>().position.z;
            p=objetos[n].gameObject.GetComponent<Transform>().rotation;
           

            if(objetos[n].gameObject.tag == "agarrado")
            {
                tg[n] = 0;
                vy[n] = 0;
            }
            else
            {
                if (y[n] > 0.5)
                {
                    gravedad(n);
                    tg[n] += Time.deltaTime;
                }
                else
                {
                    tg[n] = 0;
                    vy[n] = 0;
                    y[n] = 0.5f;
                }
                objetos[n].gameObject.GetComponent<Transform>().position = new Vector3(x[n],y[n],z[n]);


            }
            
        }
    }

}
