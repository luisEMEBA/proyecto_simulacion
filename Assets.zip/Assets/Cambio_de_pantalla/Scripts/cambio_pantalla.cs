﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class cambio_pantalla : MonoBehaviour {

    public void a_simulacion(string nombredeescena)
    {

        SceneManager.LoadScene(1);
}
    public void a_menu(string nombredeescena)
    {

        SceneManager.LoadScene(0);
}
}