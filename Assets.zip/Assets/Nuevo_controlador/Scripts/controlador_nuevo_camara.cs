﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class controlador_nuevo_camara : MonoBehaviour
{   
    public float velocidad_rotacion = 1;
    public Transform objetivo, dron, gancho;
    float mouseX, mouseY;
    // Start is called before the first frame update
    void Start()
    {
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        ControlCamara();
    }
    void ControlCamara(){
        mouseX += Input.GetAxis("Mouse X") * velocidad_rotacion;
        mouseY -= Input.GetAxis("Mouse Y") * velocidad_rotacion;
        mouseY = Mathf.Clamp(mouseY, -35, 60);
        transform.LookAt(objetivo);
        objetivo.rotation = Quaternion.Euler(mouseY, mouseX, 0);
        dron.rotation = Quaternion.Euler(0,mouseX,0);
        gancho.rotation = Quaternion.Euler(0,mouseX,0);
    }
}
